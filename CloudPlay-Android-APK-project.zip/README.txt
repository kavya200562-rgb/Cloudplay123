CLOUDPLAY ANDROID APK PROJECT

This is an Android WebView wrapper around the CloudPlay demo interface.
It is NOT a real cloud gaming service and does not stream GTA 5 yet.

BUILD AN APK USING GITHUB (phone-friendly route):
1. Sign in to GitHub in your browser and create a new repository named CloudPlay.
2. Upload the contents of this ZIP to the repository (upload files/folders, keeping the same folder structure).
3. Open the repository's Actions tab.
4. Select "Build CloudPlay APK" and press "Run workflow" if it has not started automatically.
5. Wait for the workflow to finish, open the successful run, and download the "CloudPlay-debug-APK" artifact.
6. Extract the downloaded artifact ZIP to get app-debug.apk.
7. Install the APK on your Android phone. Android may ask you to allow installation from that browser/file manager.

The build workflow requires internet access in GitHub Actions. GitHub's service limits and policies may change.

IMPORTANT:
- This is a debug APK build setup, not a signed Play Store release.
- It is a prototype UI. Game buttons only show demo messages.
- Real streaming requires a compatible remote gaming host or provider and game licences/permissions.
